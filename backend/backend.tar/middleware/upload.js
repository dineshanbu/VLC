const multer = require('multer');
const path = require('path');
const fs = require('fs');

const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Storage engine config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const sanitizedOriginal = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
    cb(null, `${uniqueSuffix}-${sanitizedOriginal}`);
  }
});

// File filter for general uploads (images, pdf, doc, video)
const fileFilter = (req, file, cb) => {
  const allowedExtensions = /jpeg|jpg|png|webp|gif|svg|pdf|doc|docx|mp4|mov|webm/;
  const extname = allowedExtensions.test(path.extname(file.originalname).toLowerCase());
  if (extname) {
    return cb(null, true);
  }
  cb(new Error('Only images, PDFs, Documents, and Video files are allowed!'));
};

const upload = multer({
  storage: storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB max file size
  fileFilter: fileFilter
});

// Home facility gallery files are kept in their own folder so they can be
// moved to a production server together with a single, clearly named folder.
const facilityGalleryDir = path.join(uploadDir, 'facility-gallery');
if (!fs.existsSync(facilityGalleryDir)) {
  fs.mkdirSync(facilityGalleryDir, { recursive: true });
}

const facilityUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, facilityGalleryDir),
    filename: (_req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
      const sanitizedOriginal = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
      cb(null, `${uniqueSuffix}-${sanitizedOriginal}`);
    }
  }),
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter
});

module.exports = upload;
module.exports.facilityUpload = facilityUpload;
